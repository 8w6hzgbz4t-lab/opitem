"""Export all detailed collectibles, previews, and importable gallery."""
from copy import deepcopy
import html
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, ImageFont, ImageOps

from build_puzzle_asset import export_xml, preview

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"releases/DetailedArt"
ITEMS=json.loads((ROOT/"docs/art-catalog.json").read_text())

def gallery():
    root=ET.Element("roblox",version="4")
    folder=ET.SubElement(root,"Item",{"class":"Folder","referent":"RBX_DetailedItemGallery"})
    props=ET.SubElement(folder,"Properties")
    ET.SubElement(props,"string",name="Name").text="DetailedItemGallery"
    for index,item in enumerate(ITEMS):
        child=deepcopy(ET.parse(OUT/"items"/f"{item['id']}.rbxmx").getroot().find("Item"))
        for node in child.iter("Item"):
            node.attrib["referent"]=item["id"]+"_"+node.attrib["referent"]
        for ref in child.iter("Ref"):
            if ref.text and ref.text!="null":ref.text=item["id"]+"_"+ref.text
        offset=((index%7-3)*8,1,(index//7-2.5)*9)
        for cf in child.iter("CoordinateFrame"):
            if cf.attrib.get("name")=="CFrame":
                for key,delta in zip(("X","Y","Z"),offset):
                    node=cf.find(key);node.text=str(float(node.text)+delta)
        folder.append(child)
    ET.ElementTree(root).write(OUT/"DetailedItemGallery.rbxmx",encoding="utf-8",xml_declaration=True)

def contact(items,target,columns):
    tile_w,tile_h=300,365
    rows=(len(items)+columns-1)//columns
    canvas=Image.new("RGB",(columns*tile_w,rows*tile_h),"#171321")
    draw=ImageDraw.Draw(canvas)
    font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",16)
    small=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",12)
    for index,item in enumerate(items):
        x,y=(index%columns)*tile_w,(index//columns)*tile_h
        image=Image.open(OUT/"items"/f"{item['id']}.png").convert("RGB")
        image=ImageOps.contain(image,(tile_w-12,tile_h-60))
        canvas.paste(image,(x+(tile_w-image.width)//2,y))
        name=item["name"];lines=[]
        while len(name)>29:
            split=name.rfind(" ",0,29)
            if split<1:split=29
            lines.append(name[:split]);name=name[split:].strip()
        lines.append(name)
        for row,line in enumerate(lines[:2]):
            box=draw.textbbox((0,0),line,font=font)
            draw.text((x+(tile_w-(box[2]-box[0]))//2,y+tile_h-57+row*20),line,font=font,fill="#f6e8ce")
        draw.text((x+10,y+tile_h-17),item["id"],font=small,fill="#b29ecb")
    canvas.save(target)

def main():
    OUT.mkdir(exist_ok=True);(OUT/"items").mkdir(exist_ok=True)
    stats=[]
    for item in ITEMS:
        path=Path("/tmp/opitem-art-specs")/f"{item['id']}.json"
        spec=json.loads(path.read_text())
        export_xml(spec,OUT/"items"/f"{item['id']}.rbxmx")
        image=OUT/"items"/f"{item['id']}.png"
        if not image.exists():
            preview(spec,image)
        stats.append({**item,"parts":len(spec["parts"]),"size":spec.get("bounds",{}).get("size")})
        print(f"Exported {item['id']}: {item['name']} ({len(spec['parts'])} parts)",flush=True)
    gallery()
    contact(ITEMS,OUT/f"All{len(ITEMS)}Items.png",6)
    for i in range((len(ITEMS)+13)//14):
        contact(ITEMS[i*14:(i+1)*14],OUT/f"Collection-{i+1:02d}.png",4)
    (OUT/"item-manifest.json").write_text(json.dumps(stats,indent=2,ensure_ascii=False))
    cards=[]
    for item in ITEMS:
        identifier=item["id"]
        cards.append(f'<article><a href="items/{identifier}.png"><img src="items/{identifier}.png" alt="{html.escape(item["name"])}"></a><h2>{html.escape(item["name"])}</h2><p>{identifier} · <a href="items/{identifier}.rbxmx">Roblox model</a></p></article>')
    (OUT/"gallery.html").write_text("""<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Steal An OP Item — all detailed models</title>
<style>body{margin:28px;background:#171321;color:#f6e8ce;font:16px system-ui}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px}article{background:#221b30;border-radius:12px;padding:12px}img{width:100%;height:280px;object-fit:contain}h2{font-size:17px}a{color:#d4b4ff}p{color:#c1b2d3}</style>
<h1>All detailed collectibles</h1><p>Previews are offline renders of the actual geometry. Roblox Studio lighting will differ.</p><main>"""+''.join(cards)+"</main>")
    print(f"PASS: exported {len(ITEMS)} models, {len(ITEMS)} previews, importable gallery, contact pages and manifest.")

if __name__=="__main__":
    main()
