local Mock=dofile('tools/roblox_mock.lua')
local E=Mock.loadModule('roblox/art/ExtraDecor.lua')
local function save(model,name)
 local f=assert(io.open('/tmp/opitem-'..name..'.json','w'))
 f:write(Mock.json(Mock.record(model)));f:close()
end
for name,build in pairs({CrimsonDragon=E.crimsonDragon,Shenron=E.shenron,MirrorForce=E.mirrorForcePlanet,Racetrack=E.racetrack}) do
 save(build(nil,CFrame.new()),name)
end
local model=Instance.new('Model');model.Name='RaisedTrackWithPerimeterWalls'
local root=Instance.new('Part');root.Name='Root';root.Anchored=true;root.Transparency=1
root.CanCollide=false;root.CanQuery=false;root.CanTouch=false;root.Parent=model;model.PrimaryPart=root
E.racetrack(model)
Mock.loadModule('roblox/game/ArenaBounds.lua').build({folder=model})
save(model,'RaisedTrackWithWalls')
print('Recorded requested scenic models and elevated circuit with actual perimeter walls')
