-- Offline geometry recorder. This does not replace a Studio playtest.
local V={}
V.__index=function(v,k)
 if k=="Magnitude" then return math.sqrt(v.X*v.X+v.Y*v.Y+v.Z*v.Z) end
 if k=="Unit" then local n=v.Magnitude; assert(n>0,"zero unit vector"); return v/n end
 return V[k]
end
Vector3={}
function Vector3.new(x,y,z) return setmetatable({X=x or 0,Y=y or 0,Z=z or 0},V) end
Vector3.zero=Vector3.new()
V.__add=function(a,b) return Vector3.new(a.X+b.X,a.Y+b.Y,a.Z+b.Z) end
V.__sub=function(a,b) return Vector3.new(a.X-b.X,a.Y-b.Y,a.Z-b.Z) end
V.__unm=function(a) return Vector3.new(-a.X,-a.Y,-a.Z) end
V.__mul=function(a,b)
 if type(a)=="number" then a,b=b,a end
 assert(type(b)=="number","scalar multiplication required")
 return Vector3.new(a.X*b,a.Y*b,a.Z*b)
end
V.__div=function(a,b) return a*(1/b) end
function V:Dot(b) return self.X*b.X+self.Y*b.Y+self.Z*b.Z end
function V:Cross(b) return Vector3.new(self.Y*b.Z-self.Z*b.Y,self.Z*b.X-self.X*b.Z,self.X*b.Y-self.Y*b.X) end
function V:Lerp(b,t) return self+(b-self)*t end

local CF={}
CF.__index=function(c,k)
 if k=="Position" or k=="p" then return c.position end
 if k=="RightVector" then return Vector3.new(c.r[1],c.r[4],c.r[7]) end
 if k=="UpVector" then return Vector3.new(c.r[2],c.r[5],c.r[8]) end
 if k=="LookVector" then return -Vector3.new(c.r[3],c.r[6],c.r[9]) end
 return CF[k]
end
local function frame(p,r) return setmetatable({position=p,r=r},CF) end
CFrame={}
function CFrame.new(x,y,z)
 if type(x)=="table" then return frame(x,{1,0,0,0,1,0,0,0,1}) end
 return frame(Vector3.new(x,y,z),{1,0,0,0,1,0,0,0,1})
end
CFrame.identity=CFrame.new()
function CFrame.fromMatrix(p,x,y,z)
 z=z or x:Cross(y)
 return frame(p,{x.X,y.X,z.X,x.Y,y.Y,z.Y,x.Z,y.Z,z.Z})
end
local function rotate(c,v)
 local r=c.r
 return Vector3.new(r[1]*v.X+r[2]*v.Y+r[3]*v.Z,r[4]*v.X+r[5]*v.Y+r[6]*v.Z,r[7]*v.X+r[8]*v.Y+r[9]*v.Z)
end
CF.__mul=function(a,b)
 if getmetatable(b)==V then return a.position+rotate(a,b) end
 local out={}
 for i=0,2 do for j=1,3 do
  out[i*3+j]=a.r[i*3+1]*b.r[j]+a.r[i*3+2]*b.r[3+j]+a.r[i*3+3]*b.r[6+j]
 end end
 return frame(a.position+rotate(a,b.position),out)
end
CF.__add=function(a,b) return frame(a.position+b,a.r) end
CF.__sub=function(a,b) return frame(a.position-b,a.r) end
function CFrame.Angles(x,y,z)
 local sx,cx,sy,cy,sz,cz=math.sin(x),math.cos(x),math.sin(y),math.cos(y),math.sin(z),math.cos(z)
 return frame(Vector3.zero,{1,0,0,0,cx,-sx,0,sx,cx})
  *frame(Vector3.zero,{cy,0,sy,0,1,0,-sy,0,cy})
  *frame(Vector3.zero,{cz,-sz,0,sz,cz,0,0,0,1})
end
function CF:Inverse()
 local r=self.r
 local inverse=frame(Vector3.zero,{r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]})
 inverse.position=rotate(inverse,-self.position)
 return inverse
end
function CF:GetComponents() return self.position.X,self.position.Y,self.position.Z,table.unpack(self.r) end

Color3={}
function Color3.fromRGB(r,g,b) return {R=r/255,G=g/255,B=b/255} end
function Color3.new(r,g,b) return {R=r,G=g,B=b} end
Enum={Material={Metal="Metal",Neon="Neon",SmoothPlastic="SmoothPlastic"},PartType={Block="Block",Ball="Ball",Cylinder="Cylinder"}}
Enum.SurfaceType={Smooth="Smooth"}
local methods={}
local I={}
I.__index=function(i,k)
 if k=="Position" and i._props.CFrame then return i._props.CFrame.Position end
 return methods[k] or i._props[k]
end
I.__newindex=function(i,k,v)
 if k=="Parent" then
  local old=i._props.Parent
  if old then for n,c in ipairs(old._children) do if c==i then table.remove(old._children,n); break end end end
  if v then v._children[#v._children+1]=i end
 end
 i._props[k]=v
end
Instance={}
function Instance.new(class,parent)
 assert(class=="Model" or class=="Part" or class=="WedgePart","unsupported instance "..class)
 local i=setmetatable({_class=class,_children={},_attrs={},_props={Name=class}},I)
 if class~="Model" then
  i.CFrame=CFrame.new(); i.Size=Vector3.new(1,1,1); i.Color=Color3.new(1,1,1)
  i.Material="SmoothPlastic"; i.Shape="Block"; i.Transparency=0
  i.Anchored=false; i.CanCollide=true; i.CanQuery=true; i.CanTouch=true
 end
 i.Parent=parent
 return i
end
function methods:SetAttribute(k,v) self._attrs[k]=v end
function methods:GetAttribute(k) return self._attrs[k] end
function methods:GetChildren() return self._children end
function methods:GetDescendants()
 local out={}
 local function walk(i) for _,c in ipairs(i._children) do out[#out+1]=c; walk(c) end end
 walk(self); return out
end
function methods:IsA(class) return self._class==class or (class=="BasePart" and self._class~="Model") end
function methods:GetPivot() return self._props._pivot or (self.PrimaryPart and self.PrimaryPart.CFrame) or CFrame.new() end
function methods:PivotTo(cf)
 local transform=cf*self:GetPivot():Inverse()
 for _,p in ipairs(self:GetDescendants()) do if p:IsA("BasePart") then p.CFrame=transform*p.CFrame end end
 self._props._pivot=cf
end

local function json(value)
 local kind=type(value)
 if kind=="string" then return '"'..value:gsub('\\','\\\\'):gsub('"','\\"'):gsub('\n','\\n'):gsub('\r','\\r')..'"' end
 if kind=="number" then assert(value==value and math.abs(value)<math.huge,"nonfinite value"); return string.format("%.12g",value) end
 if kind=="boolean" then return tostring(value) end
 assert(kind=="table","unsupported JSON value")
 local out={}
 if #value>0 then for _,v in ipairs(value) do out[#out+1]=json(v) end; return "["..table.concat(out,",").."]" end
 for k,v in pairs(value) do out[#out+1]=json(k)..":"..json(v) end
 table.sort(out); return "{"..table.concat(out,",").."}"
end
local module=dofile(arg[1])
local parent=Instance.new("Model")
local model=module.create(parent)
assert(model and model.PrimaryPart,"model root missing")
local result={name=model.Name,attributes=model._attrs,parts={}}
for _,p in ipairs(model:GetDescendants()) do
 if p:IsA("BasePart") then
  assert(p.Anchored and not p.CanCollide,"collectible must be anchored and noncolliding")
  assert(p.Size.X>0 and p.Size.Y>0 and p.Size.Z>0,"invalid size")
  result.parts[#result.parts+1]={name=p.Name,class=p._class,size={p.Size.X,p.Size.Y,p.Size.Z},
   cf={p.CFrame:GetComponents()},color={p.Color.R,p.Color.G,p.Color.B},material=p.Material,
   shape=p.Shape,transparency=p.Transparency,canQuery=p.CanQuery,canTouch=p.CanTouch,
   primary=p==model.PrimaryPart}
 end
end
local file=assert(io.open(arg[2],"w")); file:write(json(result)); file:close()
print("Recorded "..#result.parts.." parts into "..arg[2])
assert(model:GetAttribute("PartCount")==#result.parts,"part count metadata mismatch")
assert(#result.parts<=180,"part budget exceeded")
assert(model.Parent==parent,"parent assignment failed")
local transform=CFrame.new(10,20,30)*CFrame.Angles(.1,.7,-.2)
local scaled=module.create(nil,{scale=2,cframe=transform,itemId="item08"})
assert(scaled:GetAttribute("Kind")=="item08","catalog binding missing")
local a,b=model:GetDescendants(),scaled:GetDescendants()
assert(#a==#b,"scaled instance part count changed")
for i,p in ipairs(a) do
 local other=b[i]
 assert((other.Size-p.Size*2).Magnitude<1e-8,"scale mismatch")
 assert((other.CFrame.Position-transform*(p.CFrame.Position*2)).Magnitude<1e-8,"pivot/scale placement mismatch")
 assert(other.Anchored and not other.CanCollide and not other.CanQuery and not other.CanTouch,"unsafe visual part")
end
for _,invalid in ipairs({0,-1,math.huge,0/0}) do
 assert(not pcall(function() module.create(nil,{scale=invalid}) end),"invalid scale accepted")
end
print("PASS: part budget, parent, catalog binding, scaling, rotated placement, collision flags, invalid inputs")
