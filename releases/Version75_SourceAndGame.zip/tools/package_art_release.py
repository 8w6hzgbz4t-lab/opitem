"""Validate and package the complete version 63 handoff."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).resolve().parents[1]
RELEASE=ROOT/'releases/StealAnOPItem_63_DetailedArt.rbxlx'
PACK=ROOT/'releases/StealAnOPItem_63_Complete.zip'
ART=ROOT/'releases/DetailedArt'

def name(node):
    return node.findtext("Properties/string[@name='Name']")

def check_xml(path):
    root=ET.parse(path).getroot()
    nodes=list(root.iter('Item'))
    refs={node.attrib['referent'] for node in nodes}
    assert len(refs)==len(nodes),f'Duplicate referents in {path.name}'
    for ref in root.iter('Ref'):
        assert ref.text in refs or ref.text in ('null','nil',None),f'Dangling reference in {path.name}'
    return root

def main():
    root=check_xml(RELEASE)
    service=next(i for i in root.findall('Item') if i.attrib['class']=='ServerScriptService')
    game=next(i for i in service.findall('Item') if name(i)=='OPItemV2')
    nodes={name(i):i for i in game.findall('Item')}
    for path in (ROOT/'roblox/game').glob('*.lua'):
        assert nodes[path.stem].findtext("Properties/ProtectedString[@name='Source']")==path.read_text(),f'Stale game source {path.name}'
    art_nodes={name(i):i for i in nodes['DetailedArt'].findall('Item')}
    for path in (ROOT/'roblox/art').glob('*.lua'):
        if path.stem=='SpawnWeights':continue # Optional helper; actual Catalog already reduces weights.
        assert art_nodes[path.stem].findtext("Properties/ProtectedString[@name='Source']")==path.read_text(),f'Stale art source {path.name}'
    manifest=json.loads((ART/'item-manifest.json').read_text())
    assert len(manifest)==46
    for item in manifest:
        path=ART/'items'/f'{item["id"]}.rbxmx'
        model=check_xml(path).find('Item')
        assert model.attrib['class']=='Model' and len(list(model.iter('Item')))-1==item['parts']
        assert (ART/'items'/f'{item["id"]}.png').stat().st_size>1000
    gallery=check_xml(ART/'DetailedItemGallery.rbxmx')
    assert len(gallery.find('Item').findall('Item'))==46
    for path in ART.glob('*.rbxmx'):check_xml(path)

    files={ROOT/'README.md',RELEASE,ROOT/'roblox/original/StealAnOPItem_62_Alpha.rbxlx'}
    for directory in ('roblox/game','roblox/art','roblox/v62-original'):
        files.update((ROOT/directory).rglob('*.lua'))
    files.update(p for p in ART.rglob('*') if p.is_file() and p.name!='All42Items.png')
    for filename in ('art-catalog.json','cloud-environment.md'):
        files.add(ROOT/'docs'/filename)
    for filename in ('art_world.lua','world_integration.lua','base_entrance.lua','catalog_upgrade.lua'):
        files.add(ROOT/'tests'/filename)
    for filename in ('build_art_upgrade.py','run_game_checks.py','check_carry_presentation.py','roblox_mock.lua',
                     'record_art.lua','record_extra_decor.lua','build_puzzle_asset.py','export_art_pack.py',
                     'export_world_pack.py','package_art_release.py'):
        files.add(ROOT/'tools'/filename)
    checksums=[]
    with ZipFile(PACK,'w',ZIP_DEFLATED,compresslevel=6) as archive:
        for path in sorted(files):
            relative=path.relative_to(ROOT).as_posix()
            data=path.read_bytes()
            archive.writestr('StealAnOPItem_63/'+relative,data)
            checksums.append(hashlib.sha256(data).hexdigest()+'  '+relative)
        archive.writestr('StealAnOPItem_63/SHA256SUMS.txt','\n'.join(checksums)+'\n')
    with ZipFile(PACK) as archive:
        assert archive.testzip() is None,'Corrupt ZIP member'
    print(f'PASS: current place sources, complete models, unique references, 46-model gallery and ZIP CRC validated')
    print(f'Packaged {len(files)} files, {PACK.stat().st_size:,} bytes: {PACK.name}')

if __name__=='__main__':main()
