"""Build a source-preserving visual upgrade from the user's complete v62 place."""
from pathlib import Path
import hashlib
import shutil
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
ORIGINAL=ROOT/"roblox/original/StealAnOPItem_62_Alpha.rbxlx"
OUTPUT=ROOT/"releases/StealAnOPItem_63_DetailedArt.rbxlx"
CHANGED={"Catalog","ExpandedCatalog","ModelFactory","World","Aesthetics","BackgroundArt","Config","PhaseConfig","PhaseService","Client","ItemPresentation","Server"}
MODULES=("Primitives","MillenniumPuzzle","Weapons","Artifacts","Technology","Figures","ExtraItems","Architecture","ExtraDecor","ItemArt","LandmarkArt","WorldArt")
GAME_MODULES=("BaseEntrance",)

def name(item):
    node=item.find("Properties/string[@name='Name']")
    return node.text if node is not None else None

def module_node(module,source,referent):
    item=ET.Element("Item",{"class":"ModuleScript","referent":referent})
    props=ET.SubElement(item,"Properties")
    ET.SubElement(props,"string",name="Name").text=module
    ET.SubElement(props,"ProtectedString",name="Source").text=source
    return item

def main():
    before=hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
    tree=ET.parse(ORIGINAL)
    service=next(i for i in tree.getroot().findall("Item") if i.attrib["class"]=="ServerScriptService")
    package=next(i for i in service.findall("Item") if name(i)=="OPItemV2")
    changed=set()
    for item in package.findall("Item"):
        source=item.find("Properties/ProtectedString[@name='Source']")
        path=ROOT/"roblox/game"/f"{name(item)}.lua"
        if source is not None and path.exists():
            value=path.read_text()
            if source.text!=value:
                assert name(item) in CHANGED,f"Unexpected change: {name(item)}"
                source.text=value
                changed.add(name(item))
    assert changed==CHANGED,changed
    for module in GAME_MODULES:
        assert not any(name(i)==module for i in package.findall("Item"))
        package.append(module_node(module,(ROOT/"roblox/game"/f"{module}.lua").read_text(),"RBX_Upgrade_"+module))
    assert not any(name(i)=="DetailedArt" for i in package.findall("Item"))
    folder=ET.SubElement(package,"Item",{"class":"Folder","referent":"RBX_DetailedArt_Folder"})
    props=ET.SubElement(folder,"Properties")
    ET.SubElement(props,"string",name="Name").text="DetailedArt"
    staged=ROOT/"roblox/game/DetailedArt";staged.mkdir(exist_ok=True)
    standalone=ET.Element("roblox",version="4")
    standalone_folder=ET.SubElement(standalone,"Item",{"class":"Folder","referent":"RBX_DetailedArt_Standalone"})
    props=ET.SubElement(standalone_folder,"Properties")
    ET.SubElement(props,"string",name="Name").text="DetailedArt"
    for module in MODULES:
        path=ROOT/"roblox/art"/f"{module}.lua"
        source=path.read_text()
        folder.append(module_node(module,source,"RBX_DetailedArt_"+module))
        standalone_folder.append(module_node(module,source,"RBX_StandaloneArt_"+module))
        shutil.copy2(path,staged/path.name)
    OUTPUT.parent.mkdir(exist_ok=True)
    tree.write(OUTPUT,encoding="utf-8",xml_declaration=True)
    pack=ROOT/"releases/DetailedArt";pack.mkdir(exist_ok=True)
    ET.ElementTree(standalone).write(pack/"DetailedArtBuilders.rbxmx",encoding="utf-8",xml_declaration=True)
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()==before,"Original changed"
    original_nodes={i.attrib["referent"]:i for i in ET.parse(ORIGINAL).iter("Item")}
    new_nodes={i.attrib["referent"]:i for i in ET.parse(OUTPUT).iter("Item")}
    assert original_nodes.keys()<=new_nodes.keys(),"Original objects removed"
    source_changes=[]
    for ref,old in original_nodes.items():
        new=new_nodes[ref]
        assert old.attrib==new.attrib,"Object identity changed"
        old_props,new_props=old.find("Properties"),new.find("Properties")
        assert len(old_props)==len(new_props),"Properties added/removed on original object"
        for a,b in zip(old_props,new_props):
            assert a.tag==b.tag and a.attrib==b.attrib
            if ET.tostring(a)!=ET.tostring(b):
                assert a.tag=="ProtectedString" and a.attrib.get("name")=="Source"
                assert name(old) in CHANGED
                source_changes.append(name(old))
    assert set(source_changes)==CHANGED
    print(f"Built {OUTPUT.name}; preserved {len(original_nodes)} original objects and changed {len(CHANGED)} script sources.")
    print(f"Added {len(MODULES)} art modules; original SHA256 {before}.")

if __name__=="__main__":
    main()
