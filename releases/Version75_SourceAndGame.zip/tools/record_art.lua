-- Offline geometry recorder. Requires texlua; no Roblox assets or services.
-- Item: texlua tools/record_art.lua roblox/art/ItemArt.lua item01 /tmp/item01.json
-- Family: texlua tools/record_art.lua roblox/art/Weapons.lua --family buster /tmp/buster.json
-- Optional: --scale 2 --no-align --part-budget 1200 --model MODEL_KEY
local toolDirectory=(arg[0]:match("^(.*)/[^/]+$") or ".")
local Mock=dofile(toolDirectory.."/roblox_mock.lua")
local modulePath=assert(arg[1],"missing module path")
local family=arg[2]=="--family"
local key=assert(arg[family and 3 or 2],"missing item ID or family key")
local output=assert(arg[family and 4 or 3],"missing output JSON path")
local options={itemId=key,id=key,model=key,name=key,scale=1,partBudget=240}
local index=family and 5 or 4
while index<=#arg do
 local flag=arg[index]
 if flag=="--no-align" then options.alignBase=false
 elseif flag=="--scale" then
  index=index+1; options.scale=assert(tonumber(arg[index]),"invalid scale")
 elseif flag=="--part-budget" then
  index=index+1; options.partBudget=assert(tonumber(arg[index]),"invalid part budget")
 elseif flag=="--model" then
  index=index+1; options.model=assert(arg[index],"missing model key")
 else error("unknown option: "..tostring(flag)) end
 index=index+1
end
assert(options.scale>0 and options.scale<math.huge,"scale must be finite and positive")
assert(options.partBudget>=1 and options.partBudget<math.huge,"part budget must be finite and positive")
local module=Mock.loadModule(modulePath)
local primitives
if family then
 primitives=Mock.loadModule((modulePath:match("^(.*)/[^/]+$") or ".").."/Primitives.lua")
end
local function build(parent,settings)
 if family then
  local builder=primitives.new(parent,settings)
  assert(module.build(builder,key),"unsupported family key: "..key)
  return builder:finish()
 end
 assert(type(module.create)=="function","item module must expose create(parent, options)")
 return module.create(parent,settings)
end
local parent=Instance.new("Folder"); parent.Name="OfflineArt"
local model=build(parent,table.clone(options))
assert(model.Parent==parent,"parent assignment failed")
local recorded=Mock.record(model)
assert(#recorded.parts<=options.partBudget,"part budget exceeded: "..#recorded.parts)
local transform=CFrame.new(10,20,30)*CFrame.Angles(.1,.7,-.2)
local scaledOptions=table.clone(options)
scaledOptions.scale=options.scale*2
scaledOptions.cframe=transform
local scaled=build(nil,scaledOptions)
local originalParts=model:GetDescendants()
local scaledParts=scaled:GetDescendants()
assert(#originalParts==#scaledParts,"scaled construction changed descendant count")
local clearanceCorrection=Vector3.zero
if options.alignBase~=false then
 for i,part in ipairs(originalParts) do
  if part:IsA("BasePart") and part~=model.PrimaryPart then
   local delta=transform:PointToObjectSpace(scaledParts[i].CFrame.Position)-part.CFrame.Position*2
   -- Primitives intentionally keeps the base clearance at .04 studs at every scale.
   if (delta-Vector3.new(0,-.04,0)).Magnitude<1e-5 then clearanceCorrection=delta end
   break
  end
 end
end
for i,part in ipairs(originalParts) do
 if part:IsA("BasePart") then
  local other=scaledParts[i]
  assert(other:IsA("BasePart") and other.Name==part.Name,"scaled part order changed")
  -- Primitives uses a fixed invisible pivot marker; visible geometry must scale.
  local sizeMatches=(other.Size-part.Size*2).Magnitude<1e-6
  if part==model.PrimaryPart and part.Transparency==1 then
   sizeMatches=sizeMatches or (other.Size-part.Size).Magnitude<1e-6
  end
  assert(sizeMatches,"scale mismatch: "..part.Name)
  local correction=part==model.PrimaryPart and Vector3.zero or clearanceCorrection
  assert((other.CFrame.Position-transform*(part.CFrame.Position*2+correction)).Magnitude<1e-5,
   "pivot or scaled placement mismatch: "..part.Name)
  local expected=transform*(part.CFrame-part.CFrame.Position)
  local actual=other.CFrame-other.CFrame.Position
  local expectedComponents,actualComponents={expected:GetComponents()},{actual:GetComponents()}
  for component=4,12 do
   assert(math.abs(expectedComponents[component]-actualComponents[component])<1e-5,
    "rotated placement mismatch: "..part.Name)
  end
  assert(other.Anchored,"scaled part must be anchored")
  assert(other.CanCollide==part.CanCollide and other.CanQuery==part.CanQuery and other.CanTouch==part.CanTouch,
   "scaled collision settings changed")
 end
end
local file=assert(io.open(output,"w")); file:write(Mock.json(recorded)); file:close()
print(string.format("Recorded %s: %d parts, %.3f x %.3f x %.3f studs into %s",
 key,#recorded.parts,recorded.bounds.size[1],recorded.bounds.size[2],recorded.bounds.size[3],output))
print("PASS: finite geometry, part budget, parent assignment, scaling, rotated placement, collision consistency")
