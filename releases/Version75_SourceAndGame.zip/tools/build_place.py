"""Patch only OPItemV2 script sources in the supplied place, preserving other XML bytes."""
import argparse
import re
from pathlib import Path
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('input', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
source = args.input.read_text()
pattern = re.compile(r'<Item\b[^>]*>.*?</Properties>', re.S)
root = Path(__file__).resolve().parents[1]
modules = root / 'roblox' / 'OPItemV2'
changed = set()
# Existing XML has each Item's own Properties before its children.
package_start = source.index('<string name="Name">OPItemV2</string>')
package_end = source.index('<Item class="ServerStorage"', package_start)

def patch(match):
    block = match.group()
    if not package_start <= match.start() < package_end:
        return block
    name = re.search(r'<string name="Name">(.*?)</string>', block)
    if not name or not (modules / (name[1] + '.lua')).exists():
        return block
    file = modules / (name[1] + '.lua')
    replacement = '<ProtectedString name="Source"><![CDATA[' + file.read_text().replace(']]>', ']]]]><![CDATA[>') + ']]></ProtectedString>'
    block, count = re.subn(r'<ProtectedString name="Source">.*?</ProtectedString>', lambda _: replacement, block, flags=re.S)
    assert count == 1, name[1]
    changed.add(name[1])
    return block

output = pattern.sub(patch, source)
assert changed == {f.stem for f in modules.glob('*.lua')} - {'Conveyor'}, changed
# Insert the new module as a direct child of OPItemV2, before its Catalog child.
needle = '<Item class="ModuleScript"'
insertion = output.index(needle, output.index('<string name="Name">OPItemV2</string>'))
module = '<Item class="ModuleScript" referent="RBX_OPITEM_CONVEYOR_PHASE1"><Properties><string name="Name">Conveyor</string><ProtectedString name="Source"><![CDATA[' + (modules / 'Conveyor.lua').read_text() + ']]></ProtectedString></Properties></Item>'
output = output[:insertion] + module + output[insertion:]
ET.fromstring(output)
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(output)
print('Built', args.output, 'with', len(changed), 'existing script sources and Conveyor')
