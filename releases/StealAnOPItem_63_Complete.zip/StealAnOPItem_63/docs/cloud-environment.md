# Cloud development setup

The cloud-environment-onboarding:setup skill was used. The environment draft now saves `install_script` and `start_skill` for the existing checkout and native/offline Roblox development workflow. This does not publish the environment or Roblox game.

The current machine has Python, texlua, make, g++, NumPy 2.3.5, Pillow 12.3.0, Matplotlib 3.10.8 and the official Luau CLI, built from luau-lang/luau commit `8387cfb461b38ce09e37c1e4c2811538ef1bf5cb`. The retained CLI path is `/workspace/.cache/opitem-tools/luau`. No background services, Roblox credentials or new secrets are required.

The tested install script verifies the retained tools/imports and can rebuild the pinned Luau compiler when absent. The saved startup instructions use the existing checkout, preserve the uploaded originals, and run the native catalog/session/carry tests plus world-generation checks documented in README.md. No new Git worktree is needed.

Review and save the draft in environment settings, then publish the environment to reuse the prepared snapshot. Fresh-task restoration and Roblox Studio execution have not been tested here.
