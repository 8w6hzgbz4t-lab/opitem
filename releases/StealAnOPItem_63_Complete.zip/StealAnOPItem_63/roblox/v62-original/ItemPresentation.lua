-- Shared server presentation for every live collectible state. No ownership logic.
local P={}
function P.update(model,label,definition,catalog)
 local gui=label.Parent
 local rarity=gui:FindFirstChild('ItemRarity')
 if not rarity then
  gui.Name='ItemNameplate';gui.Size=UDim2.fromOffset(240,88);gui.MaxDistance=100
  -- Depth-tested labels avoid revealing collectibles through solid base walls.
  gui.AlwaysOnTop=false
  label.Position=UDim2.fromOffset(0,26);label.Size=UDim2.new(1,0,1,-26)
  rarity=Instance.new('TextLabel');rarity.Name='ItemRarity'
  rarity.Size=UDim2.new(1,0,0,26);rarity.BackgroundColor3=Color3.fromRGB(12,16,29)
  rarity.BackgroundTransparency=.12;rarity.Font=Enum.Font.GothamBold;rarity.TextSize=16
  rarity.TextStrokeTransparency=.6;rarity.Parent=gui
  local corner=Instance.new('UICorner');corner.CornerRadius=UDim.new(0,8);corner.Parent=rarity
 end
 rarity.Text=string.upper(definition.rarity)
 local color=catalog.Colors[definition.tier];rarity.TextColor3=Color3.fromRGB(color[1],color[2],color[3])
 model:SetAttribute('Rarity',definition.rarity);model:SetAttribute('CatalogId',definition.id)
 -- Dynamic bounding boxes support tall armor, swords, and overhead carrying.
 local cf,size=model:GetBoundingBox()
 local highest=cf.Position.Y+size.Y/2
 local root=model.PrimaryPart
 if root then gui.StudsOffset=Vector3.new(0,math.max(3.5,highest-root.Position.Y+1.8),0) end
end
return P
