-- Static procedural 2D backdrops and restrained portal ornamentation.
local B={}
function B.build(world)
 local root=Instance.new('Folder');root.Name='BackgroundArt';root.Parent=world.folder
 local function p(name,size,cf,color,material)
  local a=Instance.new('Part');a.Name=name;a.Size=size;a.CFrame=cf;a.Color=color;a.Material=material or Enum.Material.SmoothPlastic
  a.Anchored=true;a.CanCollide=false;a.CanTouch=false;a.CanQuery=false;a.CastShadow=false;a.Parent=root;return a
 end
 -- A GUI planet stays flat and readable, without imported textures or a skybox asset.
 local anchor=p('PlanetAnchor',Vector3.one,CFrame.new(118,125,-245),Color3.new(1,1,1));anchor.Transparency=1
 local gui=Instance.new('BillboardGui');gui.Name='DistantPlanet';gui.Size=UDim2.fromScale(86,86);gui.AlwaysOnTop=false;gui.LightInfluence=0;gui.MaxDistance=900;gui.Parent=anchor
 local disc=Instance.new('Frame');disc.Size=UDim2.fromScale(1,1);disc.BorderSizePixel=0;disc.BackgroundColor3=Color3.fromRGB(155,164,224);disc.Parent=gui
 Instance.new('UICorner',disc).CornerRadius=UDim.new(.5,0)
 local gradient=Instance.new('UIGradient');gradient.Rotation=35;gradient.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(228,206,249)),ColorSequenceKeypoint.new(.45,Color3.fromRGB(143,158,226)),ColorSequenceKeypoint.new(1,Color3.fromRGB(66,79,145))});gradient.Parent=disc
 local stroke=Instance.new('UIStroke');stroke.Thickness=2;stroke.Color=Color3.fromRGB(230,224,255);stroke.Transparency=.25;stroke.Parent=disc
 for i,v in ipairs({{.23,.25,.18},{.62,.35,.12},{.37,.64,.22}}) do
  local crater=Instance.new('Frame');crater.Name='PlanetMark'..i;crater.Position=UDim2.fromScale(v[1],v[2]);crater.Size=UDim2.fromScale(v[3],v[3]);crater.BorderSizePixel=0;crater.BackgroundColor3=Color3.fromRGB(105,117,191);crater.BackgroundTransparency=.55;crater.Parent=disc;Instance.new('UICorner',crater).CornerRadius=UDim.new(.5,0)
 end
 -- An opaque, distant skydome establishes a consistent blue/lavender backdrop.
 local backdrop=Color3.fromRGB(151,179,222)
 for _,side in ipairs({-1,1}) do
  p('LavenderSkyBackdrop',Vector3.new(1,2000,2000),CFrame.new(side*1000,0,0),backdrop,Enum.Material.Neon)
  p('LavenderSkyBackdrop',Vector3.new(2000,1,2000),CFrame.new(0,side*1000,0),backdrop,Enum.Material.Neon)
  p('LavenderSkyBackdrop',Vector3.new(2000,2000,1),CFrame.new(0,0,side*1000),backdrop,Enum.Material.Neon)
 end
 -- Ring ornaments occupy the YZ portal plane; the spawn lane at Y=2.5,Z=0 stays clear.
 local gold=Color3.fromRGB(240,194,86);local purple=Color3.fromRGB(169,104,255)
 for i=0,31 do
  local a=i*math.pi/16;local b=(i+1)*math.pi/16
  local from=Vector3.new(119,10+math.sin(a)*9.1,math.cos(a)*9.1)
  local to=Vector3.new(119,10+math.sin(b)*9.1,math.cos(b)*9.1)
  p('PortalOuterFrame',Vector3.new(.6,.6,(to-from).Magnitude),CFrame.lookAt((from+to)/2,to),gold,Enum.Material.Metal)
 end
 for i=0,7 do
  local a=i*math.pi/4
  -- Lower central runes are deliberately omitted near the moving offers.
  if math.sin(a)>-.6 then
   local rune=p('SuspendedRune',Vector3.new(.18,.8,.8),CFrame.new(118.5,10+math.sin(a)*11,math.cos(a)*11)*CFrame.Angles(math.pi/4,0,0),purple,Enum.Material.Neon)
   rune.Transparency=.15
  end
 end
 for _,z in ipairs({-8.8,8.8}) do
  local trim=p('PortalLuminousTrim',Vector3.new(.15,12,.2),CFrame.new(118.7,10,z),purple,Enum.Material.Neon)
  local attachment=Instance.new('Attachment');attachment.Parent=trim
  local emitter=Instance.new('ParticleEmitter');emitter.Name='PortalSparks';emitter.Rate=3;emitter.Lifetime=NumberRange.new(.8,1.2);emitter.Speed=NumberRange.new(.2,.6)
  emitter.Texture='rbxasset://textures/particles/sparkles_main.dds';emitter.SpreadAngle=Vector2.new(15,15);emitter.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,.14),NumberSequenceKeypoint.new(1,0)})
  emitter.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,.4),NumberSequenceKeypoint.new(1,1)});emitter.Color=ColorSequence.new(purple);emitter.LightEmission=.4;emitter.Parent=attachment
 end
 return root
end
return B
