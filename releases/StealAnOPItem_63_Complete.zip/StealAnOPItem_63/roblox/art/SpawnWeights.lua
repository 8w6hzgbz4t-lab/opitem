-- Weighted spawning without changing catalog IDs, tiers, prices, or income.
--
-- Baseline per-item weight = tierWeight * itemWeight / sum(itemWeights in tier).
-- A finite, positive item.spawnWeight is the item's conditional tier weight.
-- item.itemSpawnWeight is its fallback alias. Missing/invalid values use 1.
-- This preserves both uniform legacy tiers and v60's weighted tier pools when
-- the Pokemon multiplier is 1. Neither field changes the item's rarity label.
-- Pass INITIALIZED catalog items. v62 already applies its original 0.4 factor
-- to spawnWeight when loading; this helper never reapplies SpawnSettings.
-- The argument is an additional reduction relative to those current weights.
-- Pokémon receives a further multiplier (default 0.5). This applies across
-- all tiers, including a tier containing only Pokémon. A multiplier of zero
-- excludes Pokémon; if nothing remains, roll raises an explicit error.

local SpawnWeights = {}

local function finite(value)
    return type(value) == "number" and value == value
        and value > -math.huge and value < math.huge
end

local function positive(value)
    return finite(value) and value > 0
end

local function normalized(value)
    if type(value) ~= "string" then return "" end
    return string.lower(value:gsub("É", "e"):gsub("é", "e"))
        :gsub("[^a-z0-9]", "")
end

local metadataFields = { "franchise", "universe", "source", "category" }
local pokemonNames = {
    "pokeball", "masterball", "greatball", "ultraball", "safariball",
    "premierball", "luxuryball", "diveball", "duskball", "healball",
    "netball", "quickball", "repeatball", "timerball", "missingno",
    "evolutionstone", "pikachu", "charizard", "mewtwo", "rayquaza",
    "lugia", "hooh", "arceus", "legendfeather", "rainbowlegendaryfeather",
}
local evolutionNames = {
    firestone = true, waterstone = true, thunderstone = true,
    leafstone = true, moonstone = true, sunstone = true,
    shinystone = true, duskstone = true, dawnstone = true,
    icestone = true,
}

function SpawnWeights.isPokemon(item, pokemonIds)
    if type(item) ~= "table" then return false end
    if type(pokemonIds) == "table" and pokemonIds[item.id] == true then
        return true
    end
    for _, field in ipairs(metadataFields) do
        if normalized(item[field]):find("pokemon", 1, true) then
            return true
        end
    end

    for _, field in ipairs({ "model", "name" }) do
        local text = normalized(item[field])
        if text:find("pokemon", 1, true) or evolutionNames[text] then
            return true
        end
        for _, name in ipairs(pokemonNames) do
            if text:find(name, 1, true) then return true end
        end
    end

    -- Explicit compatibility with the existing sixteen-item catalog.
    -- Other catalogs should supply franchise metadata for ambiguous designs.
    return item.id == "item12"
        and (normalized(item.model) == "masterball"
            or normalized(item.name) == "masterball")
end

local function itemWeight(item)
    local weight = item.spawnWeight
    if not positive(weight) then weight = item.itemSpawnWeight end
    if not positive(weight) then weight = 1 end
    return weight
end

function SpawnWeights.roll(catalog, rng, pokemonMultiplier)
    if pokemonMultiplier == nil then pokemonMultiplier = 0.5 end
    assert(finite(pokemonMultiplier) and pokemonMultiplier >= 0,
        "Pokemon spawn multiplier must be a finite nonnegative number")
    assert(type(catalog) == "table" and type(catalog.Items) == "table",
        "Spawn catalog must provide Items")
    assert(type(catalog.Weights) == "table",
        "Spawn catalog must provide tier Weights")
    assert(rng and type(rng.NextNumber) == "function",
        "Spawn RNG must provide NextNumber")
    local pokemonIds = type(catalog.SpawnSettings) == "table"
        and catalog.SpawnSettings.PokemonIds or nil

    local tierTotals = {}
    for _, item in ipairs(catalog.Items) do
        local tier = item.tier
        if positive(tier) and tier % 1 == 0 then
            tierTotals[tier] = (tierTotals[tier] or 0) + itemWeight(item)
            assert(finite(tierTotals[tier]), "Spawn tier item weight overflow")
        end
    end

    local entries, total = {}, 0
    -- Tier order preserves the legacy zero and upper-boundary behavior.
    for tier, tierWeight in ipairs(catalog.Weights) do
        local tierTotal = tierTotals[tier] or 0
        if positive(tierWeight) and tierTotal > 0 then
            for _, item in ipairs(catalog.Items) do
                if item.tier == tier then
                    assert(type(item.id) == "string" and item.id ~= "",
                        "Spawn item must have a nonempty string ID")
                    local weight = tierWeight * (itemWeight(item) / tierTotal)
                    if SpawnWeights.isPokemon(item, pokemonIds) then
                        weight = weight * pokemonMultiplier
                    end
                    assert(finite(weight), "Spawn item weight overflow")
                    if weight > 0 then
                        total = total + weight
                        assert(finite(total), "Spawn total weight overflow")
                        entries[#entries + 1] = { id = item.id, weight = weight }
                    end
                end
            end
        end
    end

    assert(total > 0, "No eligible spawn items: check tier weights and Pokemon multiplier")
    local fraction = rng:NextNumber()
    assert(finite(fraction) and fraction >= 0 and fraction <= 1,
        "Spawn RNG NextNumber must be between zero and one")
    local value = fraction * total
    for _, entry in ipairs(entries) do
        if value < entry.weight then return entry.id end
        value = value - entry.weight
    end
    -- Accommodate RNGs returning exactly 1 and floating-point subtraction.
    return entries[#entries].id
end

return SpawnWeights
