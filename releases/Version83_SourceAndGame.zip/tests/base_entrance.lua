return function(packageRoot,requireModule)
 local Entrance=requireModule(packageRoot.BaseEntrance)
 local Config=requireModule(packageRoot.Config)
 local Phase=requireModule(packageRoot.PhaseConfig)
 local Core=requireModule(packageRoot.Core)
 local Catalog=requireModule(packageRoot.Catalog)
 local checked=0
 local function check(value,message) assert(value,message);checked=checked+1 end
 local cf={PointToObjectSpace=function(_,p)return p end}
 for _,x in ipairs({-23,-17,0,17,23}) do
  for _,z in ipairs({-26,-24,-22,-18,-16}) do
   check(Entrance.contains(cf,{X=x,Y=3,Z=z}),'Full entrance width/depth must deliver')
  end
 end
 check(Entrance.contains(cf,{X=0,Y=3,Z=-12}),'Original delivery pad remains usable')
 for _,p in ipairs({{X=23.1,Y=3,Z=-22},{X=0,Y=.49,Z=-22},{X=0,Y=11.1,Z=-22},{X=0,Y=3,Z=-26.1},{X=12,Y=3,Z=-15.9}}) do
  check(not Entrance.contains(cf,p),'Out-of-zone point accepted')
 end
 local rotated={PointToObjectSpace=function(_,p)return {X=-p.Z,Y=p.Y,Z=p.X} end}
 check(Entrance.contains(rotated,{X=-22,Y=3,Z=-20}),'Rotated bases use local coordinates')
 check(Phase.HoldSeconds==.35 and Phase.HoldJitter<=.05,'Grab/steal hold must be 0.35s')
 check(Config.ProtectionDuration==30,'Protection must last 30 seconds')
 local core=Core.new(Catalog,Config)
 core:addPlayer(101,0);core:addPlayer(202,0)
 check(not Entrance.activate(core,101,202,31),'Visitor must not renew another base')
 check(not Entrance.activate(core,303,303,31),'Missing player must not renew protection')
 check(not Entrance.activate(core,101,101,29.99),'Spawn recharge must be respected')
 check(Entrance.activate(core,101,101,30),'Ready owner crossing must protect')
 check(core.players[101].lockUntil==60,'Protection timer must start at 30 seconds')
 check(core.players[101].lockReady==90,'Existing 60 second recharge retained')
 check(not Entrance.activate(core,101,101,30.1),'Repeated crossings must not extend protection')
 check(Entrance.activate(core,101,101,90),'Ready protection can renew again')
 check(core.players[101].lockUntil==120,'Renewed protection lasts 30 seconds')
 return string.format('%d checks: broad/local entrance, owner-only renewal, cooldown, 0.35s hold and 30s protection',checked)
end
