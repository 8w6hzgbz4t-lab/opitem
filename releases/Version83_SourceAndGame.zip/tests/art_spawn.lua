local SpawnWeights = dofile("roblox/art/SpawnWeights.lua")
local Catalog = dofile("roblox/OPItemV2/Catalog.lua")
local checks = 0
local function check(ok, message)
    assert(ok, message)
    checks = checks + 1
end
local function fixed(value)
    return { NextNumber = function() return value end }
end
local function fails(fn, message)
    check(not pcall(fn), message)
end
local function generator(seed)
    return { NextNumber = function()
        seed = seed * 16807 % 2147483647
        return (seed - 1) / 2147483646
    end }
end
local function catalog(items, weights)
    return { Items = items, Weights = weights }
end

check(loadfile("roblox/art/SpawnWeights.lua") ~= nil, "helper parses")
check(SpawnWeights.isPokemon(Catalog.ById.item12), "legacy Master Ball detected")
for _, item in ipairs(Catalog.Items) do
    if item.id ~= "item12" then
        check(not SpawnWeights.isPokemon(item), item.id .. " is not Pokemon")
    end
end
for _, field in ipairs({ "franchise", "universe", "source", "category" }) do
    check(SpawnWeights.isPokemon({ [field] = "Pokémon" }), field .. " accent recognized")
end
for _, name in ipairs({ "MissingNo.", "Poké Ball", "Evolution Stone", "Thunder Stone", "Pikachu" }) do
    check(SpawnWeights.isPokemon({ name = name }), name .. " recognized")
end
check(not SpawnWeights.isPokemon({ name = "Green Chaos Emerald", model = "emerald" }),
    "Sonic Emerald remains non-Pokemon")
check(not SpawnWeights.isPokemon({ category = "Nintendo", model = "shell" }),
    "Nintendo does not imply Pokemon")
check(not SpawnWeights.isPokemon(nil), "absent item is safe")
check(SpawnWeights.isPokemon({ id = "customRelic" }, { customRelic = true }),
    "explicit catalog Pokemon IDs recognized")

-- With multiplier 1 and no item overrides, each legacy tier is distributed
-- uniformly exactly as before. Check both sides of every item interval.
local total = 0
for tier, weight in ipairs(Catalog.Weights) do
    if #Catalog.ByTier[tier] > 0 then total = total + weight end
end
local cumulative = 0
for tier, weight in ipairs(Catalog.Weights) do
    local pool = Catalog.ByTier[tier]
    if #pool > 0 then
        for _, item in ipairs(pool) do
            local itemWeight = weight / #pool
            check(SpawnWeights.roll(Catalog, fixed((cumulative + itemWeight * .001) / total), 1)
                == item.id, "legacy lower interval " .. item.id)
            check(SpawnWeights.roll(Catalog, fixed((cumulative + itemWeight * .999) / total), 1)
                == item.id, "legacy upper interval " .. item.id)
            cumulative = cumulative + itemWeight
        end
    end
end
check(SpawnWeights.roll(Catalog, fixed(0), 1) == "item01", "legacy common boundary")
check(SpawnWeights.roll(Catalog, fixed(.999999), 1) == "item14", "legacy Ethereal boundary")
check(SpawnWeights.roll(Catalog, fixed(1), 1) == "item14", "inclusive RNG upper boundary")

local sampleCount = 60000
local baseline, reduced = 0, 0
local baselineRng, reducedRng = generator(42), generator(42)
for _ = 1, sampleCount do
    local baselineId = SpawnWeights.roll(Catalog, baselineRng, 1)
    local reducedId = SpawnWeights.roll(Catalog, reducedRng)
    if baselineId == "item12" then baseline = baseline + 1 end
    if reducedId == "item12" then reduced = reduced + 1 end
    assert(Catalog.ById[baselineId] and Catalog.ById[reducedId], "only catalog IDs returned")
end
local expectedBaseline = 10 / 3 / 100
local expectedReduced = (10 / 3 * .5) / (100 - 10 / 3 * .5)
check(math.abs(baseline / sampleCount - expectedBaseline) < .0025,
    "baseline legacy probability")
check(math.abs(reduced / sampleCount - expectedReduced) < .0025,
    "default Pokemon probability")
check(reduced < baseline * .6 and reduced > baseline * .4,
    "Pokemon offers approximately halved")

local mixed = catalog({
    { id = "ordinary", tier = 1, name = "Sword" },
    { id = "pokemon", tier = 1, franchise = "Pokémon" },
}, { 100 })
check(SpawnWeights.roll(mixed, fixed(.6), 1) == "pokemon", "mixed tier baseline")
check(SpawnWeights.roll(mixed, fixed(.6), .5) == "ordinary", "mixed tier suppression")
check(SpawnWeights.roll(mixed, fixed(1), 0) == "ordinary", "zero excludes Pokemon")

local separate = catalog({
    { id = "ordinary", tier = 1 },
    { id = "pokemon", tier = 2, model = "missingno" },
}, { 50, 50 })
check(SpawnWeights.roll(separate, fixed(.6), 1) == "pokemon", "Pokemon-only tier baseline")
check(SpawnWeights.roll(separate, fixed(.6), .5) == "ordinary",
    "Pokemon-only tier also reduced")
local explicit = catalog({
    { id = "ordinary", tier = 1 },
    { id = "unrecognizedPokemon", tier = 2 },
}, { 50, 50 })
explicit.SpawnSettings = { PokemonIds = { unrecognizedPokemon = true } }
check(SpawnWeights.roll(explicit, fixed(.6), 1) == "unrecognizedPokemon",
    "explicit ID baseline weight")
check(SpawnWeights.roll(explicit, fixed(.6), .5) == "ordinary",
    "explicit ID reduced weight")
local onlyPokemon = catalog({ { id = "pokemon", tier = 1, source = "Pokemon" } }, { 100 })
check(SpawnWeights.roll(onlyPokemon, fixed(0), .5) == "pokemon", "positive all-Pokemon pool")
fails(function() SpawnWeights.roll(onlyPokemon, fixed(0), 0) end,
    "disabled all-Pokemon pool fails explicitly")

local overridden = catalog({
    { id = "triple", tier = 1, spawnWeight = 3 },
    { id = "single", tier = 1 },
}, { 100 })
check(SpawnWeights.roll(overridden, fixed(.70), 1) == "triple", "relative weight override")
check(SpawnWeights.roll(overridden, fixed(.80), 1) == "single", "relative override boundary")
local weightedTiers = catalog({
    { id = "tierOne", tier = 1, spawnWeight = 100 },
    { id = "tierTwoFirst", tier = 2, spawnWeight = 3 },
    { id = "tierTwoSecond", tier = 2, spawnWeight = 1 },
}, { 50, 50 })
check(SpawnWeights.roll(weightedTiers, fixed(.49), 1) == "tierOne",
    "large per-item weight does not increase tier probability")
check(SpawnWeights.roll(weightedTiers, fixed(.51), 1) == "tierTwoFirst",
    "weighted tier keeps original rarity probability")
check(SpawnWeights.roll(weightedTiers, fixed(.874), 1) == "tierTwoFirst",
    "conditional item weight normalized within tier")
check(SpawnWeights.roll(weightedTiers, fixed(.876), 1) == "tierTwoSecond",
    "conditional item weight upper boundary")
overridden.Items[1].spawnWeight = 0
overridden.Items[1].itemSpawnWeight = 3
check(SpawnWeights.roll(overridden, fixed(.70), 1) == "triple", "valid alias fallback")
for _, value in ipairs({ 0, -1, 0 / 0, math.huge, "large" }) do
    overridden.Items[1].spawnWeight = value
    overridden.Items[1].itemSpawnWeight = value
    check(SpawnWeights.roll(overridden, fixed(.6), 1) == "single", "invalid item override ignored")
end
for _, value in ipairs({ -1, 0 / 0, math.huge, "half" }) do
    fails(function() SpawnWeights.roll(Catalog, fixed(0), value) end,
        "invalid multiplier rejected")
end
for _, value in ipairs({ 0, -1, 0 / 0, math.huge, "heavy" }) do
    local invalidTier = catalog({
        { id = "disabled", tier = 1 },
        { id = "enabled", tier = 2 },
    }, { value, 10 })
    check(SpawnWeights.roll(invalidTier, fixed(0), 1) == "enabled", "invalid tier weight skipped")
end
fails(function() SpawnWeights.roll(catalog({}, { 100 }), fixed(0), 1) end,
    "empty catalog blocked")
fails(function() SpawnWeights.roll(mixed, fixed(0 / 0), 1) end, "NaN RNG blocked")
fails(function() SpawnWeights.roll(mixed, fixed(-1), 1) end, "negative RNG blocked")
fails(function() SpawnWeights.roll(mixed, fixed(2), 1) end, "out-of-range RNG blocked")

-- Rolling never modifies gameplay definitions or tier metadata.
check(Catalog.ById.item12.price == 16000 and Catalog.ById.item12.income == 220
    and Catalog.ById.item12.tier == 4 and Catalog.ById.item12.id == "item12",
    "Master Ball stats and ID untouched")
check(Catalog.Weights[4] == 10 and Catalog.Tiers[4] == "Epic", "tier settings untouched")

-- Original ID/model/tier/weight records shared by v60/v62 ExpandedCatalog.
-- Load the durable current v62 sources by default; a CLI path can check v60:
-- texlua tests/art_spawn.lua roblox/v62-original/Catalog.lua
local expandedV60 = {
    { "item17", "jellyNet", 1, 1.2 },
    { "item18", "faceMask", 2, 1 },
    { "item19", "brolyJewelry", 5, .8 },
    { "item20", "pokeBall", 1, 1.3 },
    { "item21", "evolutionStone", 2, 1 },
    { "item22", "legendFeather", 6, .65 },
    { "item23", "millenniumRod", 4, 1 },
    { "item24", "duelDisk", 3, 1 },
    { "item25", "exodiaHead", 6, .55 },
    { "item26", "exodiaLeftArm", 5, .65 },
    { "item27", "exodiaRightArm", 5, .65 },
    { "item28", "exodiaLeftLeg", 4, .8 },
    { "item29", "exodiaRightLeg", 4, .8 },
    { "item30", "diamondAxe", 2, 1 },
    { "item31", "enchantedPickaxe", 3, 1 },
    { "item32", "endCrystal", 4, .85 },
    { "item33", "commandBlock", 6, .55 },
    { "item34", "sting", 3, 1 },
    { "item35", "arkenstone", 5, .8 },
    { "item36", "dwarfTreasure", 2, 1 },
    { "item37", "materia", 3, 1 },
    { "item38", "gunblade", 4, .9 },
    { "item39", "fireStone", 2, .9 },
    { "item40", "waterStone", 2, .9 },
    { "item41", "ironArmor", 6, .55 },
    { "item42", "triforce", 6, .5 },
}
local actualV60 = catalog({}, Catalog.Weights)
for _, item in ipairs(Catalog.Items) do
    local clone = {}
    for key, value in pairs(item) do clone[key] = value end
    clone.spawnWeight = clone.spawnWeight or 1
    actualV60.Items[#actualV60.Items + 1] = clone
end
for _, record in ipairs(expandedV60) do
    actualV60.Items[#actualV60.Items + 1] = {
        id = record[1], model = record[2], tier = record[3], spawnWeight = record[4],
    }
end

local originalPath = arg and arg[1] or "roblox/v62-original/Catalog.lua"
do
    local directory = assert(originalPath:match("^(.*)/[^/]+$"), "Catalog fixture path needs a directory")
    local expanded = dofile(directory .. "/ExpandedCatalog.lua")
    local env = setmetatable({
        script = { Parent = { ExpandedCatalog = "ExpandedCatalog" } },
        require = function(module)
            assert(module == "ExpandedCatalog", "Unexpected original catalog dependency")
            return expanded
        end,
    }, { __index = _G })
    actualV60 = assert(loadfile(originalPath, "t", env))()
    check(#actualV60.Items == 42, "actual original catalog has 42 items")
    for _, record in ipairs(expandedV60) do
        local item = actualV60.ById[record[1]]
        local expectedWeight = record[4]
        if actualV60.SpawnSettings and actualV60.SpawnSettings.PokemonIds[item.id] then
            expectedWeight = expectedWeight * actualV60.SpawnSettings.PokemonWeightMultiplier
        end
        check(item.model == record[2] and item.tier == record[3]
            and item.spawnWeight == expectedWeight, "actual original matches fixture " .. record[1])
    end
end

local pokemonIds = {
    item12 = true, item20 = true, item21 = true, item22 = true,
    item39 = true, item40 = true,
}
local v60Pools, tierTotalWeight, v60Original = {}, 0, {}
for _, item in ipairs(actualV60.Items) do
    v60Pools[item.tier] = v60Pools[item.tier] or {}
    table.insert(v60Pools[item.tier], item)
    v60Original[item.id] = {}
    for key, value in pairs(item) do v60Original[item.id][key] = value end
    check(SpawnWeights.isPokemon(item, actualV60.SpawnSettings and actualV60.SpawnSettings.PokemonIds)
        == (pokemonIds[item.id] or false), "original correct franchise " .. item.id)
end
for tier, weight in ipairs(actualV60.Weights) do
    if v60Pools[tier] then tierTotalWeight = tierTotalWeight + weight end
end

local cumulativeV60, originalPokemonWeight, originalTierCumulative = 0, 0, 0
for tier, tierWeight in ipairs(actualV60.Weights) do
    local pool = v60Pools[tier]
    if pool then
        local itemTotal = 0
        for _, item in ipairs(pool) do itemTotal = itemTotal + (item.spawnWeight or 1) end
        local originalItemCumulative = 0
        for _, item in ipairs(pool) do
            local baselineWeight = tierWeight * (item.spawnWeight or 1) / itemTotal
            check(SpawnWeights.roll(actualV60,
                fixed((cumulativeV60 + baselineWeight * .001) / tierTotalWeight), 1) == item.id,
                "v60 baseline lower interval " .. item.id)
            check(SpawnWeights.roll(actualV60,
                fixed((cumulativeV60 + baselineWeight * .999) / tierTotalWeight), 1) == item.id,
                "v60 baseline upper interval " .. item.id)
            if actualV60.roll then
                local draws = {
                    (originalTierCumulative + tierWeight * .5) / tierTotalWeight,
                    (originalItemCumulative + (item.spawnWeight or 1) * .5) / itemTotal,
                }
                local drawIndex = 0
                check(actualV60.roll({ NextNumber = function()
                    drawIndex = drawIndex + 1
                    return assert(draws[drawIndex], "Unexpected original RNG draw")
                end }) == item.id, "original v60 roll agrees " .. item.id)
            end
            if pokemonIds[item.id] then originalPokemonWeight = originalPokemonWeight + baselineWeight end
            cumulativeV60 = cumulativeV60 + baselineWeight
            originalItemCumulative = originalItemCumulative + (item.spawnWeight or 1)
        end
        originalTierCumulative = originalTierCumulative + tierWeight
    end
end

local modifiedTotal = tierTotalWeight - originalPokemonWeight * .5
local reducedCumulative = 0
for tier, tierWeight in ipairs(actualV60.Weights) do
    local pool = v60Pools[tier]
    if pool then
        local itemTotal = 0
        for _, item in ipairs(pool) do itemTotal = itemTotal + (item.spawnWeight or 1) end
        for _, item in ipairs(pool) do
            local baselineWeight = tierWeight * (item.spawnWeight or 1) / itemTotal
            local modifiedWeight = baselineWeight * (pokemonIds[item.id] and .5 or 1)
            check(SpawnWeights.roll(actualV60,
                fixed((reducedCumulative + modifiedWeight * .001) / modifiedTotal)) == item.id,
                "v60 reduced lower interval " .. item.id)
            check(SpawnWeights.roll(actualV60,
                fixed((reducedCumulative + modifiedWeight * .999) / modifiedTotal)) == item.id,
                "v60 reduced upper interval " .. item.id)
            if pokemonIds[item.id] then
                check(modifiedWeight / modifiedTotal < baselineWeight / tierTotalWeight,
                    "v60 individual Pokemon reduced " .. item.id)
            end
            reducedCumulative = reducedCumulative + modifiedWeight
        end
    end
end
for _, item in ipairs(actualV60.Items) do
    local original = v60Original[item.id]
    for key, value in pairs(item) do
        check(original[key] == value, "v60 field unchanged " .. item.id .. "." .. key)
    end
    for key, value in pairs(original) do
        check(item[key] == value, "v60 field preserved " .. item.id .. "." .. key)
    end
end
if actualV60.SpawnSettings then
    check(actualV60.SpawnSettings.PokemonWeightMultiplier == .4,
        "original 0.4 Pokemon setting remains unchanged")
    check(actualV60.ById.item20.spawnWeight == 1.3 * .4,
        "original initialized Pokemon weight not multiplied again")
end
print(string.format("Optional standalone SpawnWeights on %s: Pokemon %.3f%% -> %.3f%%",
    originalPath,
    originalPokemonWeight / tierTotalWeight * 100,
    originalPokemonWeight * .5 / modifiedTotal * 100))

-- Actual game patch: halve the EXISTING setting and keep Catalog.roll intact.
-- This is tested only against v62, whose baseline multiplier is already .4.
if actualV60.SpawnSettings and actualV60.SpawnSettings.PokemonWeightMultiplier == .4 then
    local file = assert(io.open(originalPath, "r"))
    local source = file:read("*a")
    file:close()
    local patchedSource, replacements = source:gsub("PokemonWeightMultiplier=%.4,",
        "PokemonWeightMultiplier=.2,")
    check(replacements == 1, "native setting patch changes one occurrence")
    check(patchedSource:match("function C%.roll%(rng%)") ~= nil,
        "native Catalog.roll retained")
    local directory = assert(originalPath:match("^(.*)/[^/]+$"))
    local patchedExpanded = dofile(directory .. "/ExpandedCatalog.lua")
    local patchedEnvironment = setmetatable({
        script = { Parent = { ExpandedCatalog = "ExpandedCatalog" } },
        require = function(module)
            assert(module == "ExpandedCatalog", "Unexpected patched catalog dependency")
            return patchedExpanded
        end,
    }, { __index = _G })
    local patched = assert(load(patchedSource, "@native-setting-only-Catalog.lua", "t",
        patchedEnvironment))()
    check(patched.SpawnSettings.PokemonWeightMultiplier == .2, "native setting lowered to .2")
    check(#patched.Items == #actualV60.Items, "native item count preserved")
    local changedWeights = 0
    for index, original in ipairs(actualV60.Items) do
        local item = patched.Items[index]
        check(item.id == original.id, "native catalog order preserved " .. original.id)
        for key, value in pairs(original) do
            if key == "spawnWeight" and pokemonIds[original.id] then
                check(item[key] == value * .5, "native Pokemon weight halved " .. original.id)
                changedWeights = changedWeights + 1
            else
                check(item[key] == value, "native field unchanged " .. original.id .. "." .. key)
            end
        end
        for key in pairs(item) do
            check(original[key] ~= nil, "native field set preserved " .. original.id .. "." .. key)
        end
    end
    check(changedWeights == 6, "exactly six initialized Pokemon weights changed")
    for tier, label in ipairs(actualV60.Tiers) do
        check(patched.Tiers[tier] == label, "native rarity label preserved " .. tier)
        check(patched.Weights[tier] == actualV60.Weights[tier], "native tier weight preserved " .. tier)
        check(#patched.ByTier[tier] == #actualV60.ByTier[tier], "native tier pool preserved " .. tier)
        for channel, value in ipairs(actualV60.Colors[tier]) do
            check(patched.Colors[tier][channel] == value, "native rarity color preserved")
        end
    end
    for id, enabled in pairs(actualV60.SpawnSettings.PokemonIds) do
        check(patched.SpawnSettings.PokemonIds[id] == enabled, "native Pokemon ID list preserved " .. id)
    end

    local function probabilities(nativeCatalog)
        local result, totalTierWeight = {}, 0
        for tier, weight in ipairs(nativeCatalog.Weights) do
            if #nativeCatalog.ByTier[tier] > 0 then totalTierWeight = totalTierWeight + weight end
        end
        for tier, weight in ipairs(nativeCatalog.Weights) do
            local pool = nativeCatalog.ByTier[tier]
            local poolWeight = 0
            for _, item in ipairs(pool) do poolWeight = poolWeight + item.spawnWeight end
            for _, item in ipairs(pool) do
                result[item.id] = weight / totalTierWeight * item.spawnWeight / poolWeight
            end
        end
        return result
    end
    local originalProbabilities, patchedProbabilities = probabilities(actualV60), probabilities(patched)
    local originalPokemonProbability, patchedPokemonProbability = 0, 0
    for id in pairs(pokemonIds) do
        check(patchedProbabilities[id] < originalProbabilities[id], "native probability lowered " .. id)
        originalPokemonProbability = originalPokemonProbability + originalProbabilities[id]
        patchedPokemonProbability = patchedPokemonProbability + patchedProbabilities[id]
    end

    -- Exercise unchanged native roll at both boundaries of each item interval.
    local tierCursor = 0
    for tier, weight in ipairs(patched.Weights) do
        local pool, poolWeight = patched.ByTier[tier], 0
        for _, item in ipairs(pool) do poolWeight = poolWeight + item.spawnWeight end
        if #pool > 0 then
            local itemCursor = 0
            for _, item in ipairs(pool) do
                for _, intervalFraction in ipairs({ .001, .999 }) do
                    local draws = {
                        (tierCursor + weight * .5) / tierTotalWeight,
                        (itemCursor + item.spawnWeight * intervalFraction) / poolWeight,
                    }
                    local drawIndex = 0
                    check(patched.roll({ NextNumber = function()
                        drawIndex = drawIndex + 1
                        return assert(draws[drawIndex], "Unexpected native RNG draw")
                    end }) == item.id, "patched native interval " .. item.id)
                end
                itemCursor = itemCursor + item.spawnWeight
            end
            tierCursor = tierCursor + weight
        end
    end

    local nativeSamples, originalObserved, patchedObserved = 20000, 0, 0
    local originalNativeRng, patchedNativeRng = generator(2718), generator(2718)
    for _ = 1, nativeSamples do
        local originalId = actualV60.roll(originalNativeRng)
        local patchedId = patched.roll(patchedNativeRng)
        assert(actualV60.ById[originalId] and patched.ById[patchedId], "native rolls return valid items")
        if pokemonIds[originalId] then originalObserved = originalObserved + 1 end
        if pokemonIds[patchedId] then patchedObserved = patchedObserved + 1 end
    end
    check(math.abs(originalObserved / nativeSamples - originalPokemonProbability) < .01,
        "native original observed probability")
    check(math.abs(patchedObserved / nativeSamples - patchedPokemonProbability) < .01,
        "native patched observed probability")
    check(patchedObserved < originalObserved * .65, "native Pokemon count lowered")
    print(string.format("ACTUAL GAME: native setting .4 -> .2; Pokemon %.3f%% -> %.3f%% (observed %.3f%% -> %.3f%%)",
        originalPokemonProbability * 100, patchedPokemonProbability * 100,
        originalObserved / nativeSamples * 100, patchedObserved / nativeSamples * 100))
end
print(string.format("PASS: %d spawn checks; Master Ball frequency %.3f%% -> %.3f%% (%d rolls each)",
    checks, baseline / sampleCount * 100, reduced / sampleCount * 100, sampleCount))
