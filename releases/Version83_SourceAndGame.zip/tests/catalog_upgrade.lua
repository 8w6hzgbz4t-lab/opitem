-- Native Luau integration checks for the actual staged catalog and session core.
-- Run with tools/run_game_checks.py --check tests/catalog_upgrade.lua --baseline ...
return function(package, requireModule, baselinePackage)
 assert(baselinePackage, 'The catalog upgrade check requires --baseline')
 local original=requireModule(baselinePackage.Catalog)
 local current=requireModule(package.Catalog)
 local art=requireModule(package.DetailedArt.ItemArt)
 local Config=requireModule(package.Config)
 local Rules=requireModule(package.PhaseConfig)
 local Core=requireModule(package.Core)
 local checks=0
 local function check(ok,message)
  assert(ok,message);checks+=1
 end
 local pokemon={item12=true,item20=true,item21=true,item22=true,item39=true,item40=true}
 check(#original.Items==42,'The input catalog has the original 42 items')
 check(#current.Items==46,'The updated catalog has 42 upgraded items and four additions')
 check(original.SpawnSettings.PokemonWeightMultiplier==.4,'Original Pokemon multiplier is .4')
 check(current.SpawnSettings.PokemonWeightMultiplier==.2,'Updated Pokemon multiplier is .2')
 local changedWeights=0
 for index,old in ipairs(original.Items) do
  local item=current.Items[index]
  check(item.id==old.id,'Original ID and ordering preserved: '..old.id)
  for key,value in pairs(old) do
   if key=='spawnWeight' and pokemon[old.id] then
    check(item[key]==value*.5,'Pokemon relative weight halved once: '..old.id)
    changedWeights+=1
   else
    check(item[key]==value,'Original field preserved: '..old.id..'.'..key)
   end
  end
  for key in pairs(item) do
   check(old[key]~=nil,'Original field set preserved: '..old.id..'.'..key)
  end
 end
 check(changedWeights==6,'Exactly six Pokemon relative weights changed')
 for tier,label in ipairs(original.Tiers) do
  check(current.Tiers[tier]==label,'Rarity label preserved: '..tier)
  check(current.Weights[tier]==original.Weights[tier],'Rarity probability preserved: '..tier)
  for channel,value in ipairs(original.Colors[tier]) do
   check(current.Colors[tier][channel]==value,'Rarity color preserved')
  end
 end
 for id,enabled in pairs(original.SpawnSettings.PokemonIds) do
  check(current.SpawnSettings.PokemonIds[id]==enabled,'Pokemon ID list preserved: '..id)
 end
 for id in pairs(current.SpawnSettings.PokemonIds) do
  check(pokemon[id]==true,'No other franchise receives the Pokemon reduction: '..id)
 end

 local artById={}
 for _,item in ipairs(art.Items) do
  check(not artById[item.id],'No duplicate visual metadata: '..item.id)
  artById[item.id]=item
 end
 check(#art.Items==46,'All 46 collectibles have detailed visual metadata')
 local unique={}
 for index,item in ipairs(current.Items) do
  check(item.id==string.format('item%02d',index),'Contiguous original/addition ID: '..item.id)
  check(not unique[item.id] and current.ById[item.id]==item,'Unique native catalog lookup: '..item.id)
  unique[item.id]=true
  check(type(item.name)=='string' and #item.name>0,'Collectible name exists: '..item.id)
  check(type(item.price)=='number' and item.price>0 and item.price%1==0,'Valid purchase price: '..item.id)
  check(type(item.income)=='number' and item.income>0,'Valid stored income: '..item.id)
  check(type(item.spawnWeight)=='number' and item.spawnWeight>0,'Positive relative spawn weight: '..item.id)
  check(current.Tiers[item.tier]~=nil,'Valid rarity: '..item.id)
  check(art.supports(item.model),'Actual art router supports model: '..item.id..'/'..item.model)
  local visual=artById[item.id]
  check(visual and visual.name==item.name and visual.model==item.model,'Art metadata matches gameplay: '..item.id)
  local occurrences=0
  for _,pooled in ipairs(current.ByTier[item.tier]) do if pooled==item then occurrences+=1 end end
  check(occurrences==1,'Native item appears in its rarity pool once: '..item.id)
 end
 check(not art.supports('unsupported-model'),'Art router rejects unknown model metadata')

 local function rollAt(catalog,tierDraw,itemDraw)
  local draws={tierDraw,itemDraw};local index=0
  local result=catalog.roll({NextNumber=function()
   index+=1;return assert(draws[index],'Unexpected random draw')
  end})
  check(index==2,'Native catalog draws tier and item independently')
  return result
 end
 local function probabilities(catalog)
  local result,total={},0
  for tier,weight in ipairs(catalog.Weights) do
   if #catalog.ByTier[tier]>0 then total+=weight end
  end
  local tierStart=0
  for tier,weight in ipairs(catalog.Weights) do
   local pool=catalog.ByTier[tier]
   if #pool>0 then
    local itemTotal=0
    for _,item in ipairs(pool) do itemTotal+=item.spawnWeight end
    local itemStart=0
    for _,item in ipairs(pool) do
     result[item.id]=weight/total*item.spawnWeight/itemTotal
     -- Check near both edges of every native two-stage selection interval.
     for _,tierFraction in ipairs({.000001,.999999}) do
      for _,itemFraction in ipairs({.000001,.999999}) do
       check(rollAt(catalog,(tierStart+weight*tierFraction)/total,
        (itemStart+item.spawnWeight*itemFraction)/itemTotal)==item.id,
        'Native roll interval edges: '..item.id)
      end
     end
     itemStart+=item.spawnWeight
    end
    tierStart+=weight
   end
  end
  return result
 end
 local before,after=probabilities(original),probabilities(current)
 check(rollAt(current,0,0)==current.ByTier[1][1].id,'Native lower random boundary')
 local oldPokemon,newPokemon=0,0
 for id in pairs(pokemon) do
  check(after[id]<before[id],'Each Pokemon item is less common: '..id)
  oldPokemon+=before[id];newPokemon+=after[id]
 end
 check(newPokemon<oldPokemon*.6,'Aggregate Pokemon probability reduced substantially')
 local function generator(seed)
  return {NextNumber=function()
   seed=seed*16807%2147483647
   return (seed-1)/2147483646
  end}
 end
 local rng=generator(42);local samples=60000;local seenPokemon=0;local seen={}
 for _=1,samples do
  local id=current.roll(rng)
  assert(current.ById[id],'Native rolling returned an unknown item')
  seen[id]=(seen[id] or 0)+1
  if pokemon[id] then seenPokemon+=1 end
 end
 check(math.abs(seenPokemon/samples-newPokemon)<.004,'Observed Pokemon frequency matches actual weighted catalog')
 for _,id in ipairs({'item43','item44','item45','item46'}) do
  check((seen[id] or 0)>0,'New collectible appears in real native roll sampling: '..id)
 end

 -- Exercise the real unchanged transaction ledger using every new item.
 for _,kind in ipairs({'item43','item44','item45','item46'}) do
  local catalogItem=current.ById[kind]
  local c=Core.new(current,Config)
  c:addPlayer(1,0);c:addPlayer(2,0)
  c.players[1].cash=10000000;c.players[2].cash=10000000
  local startingIncome=c:income(1)
  local offer=c:setOffer('new-'..kind,kind,100,55)
  local uid=offer.uid
  check(c:purchaseAttempt(1,offer.id,offer.token,100),'New item can be purchased: '..kind)
  check(c.players[1].held==catalogItem.price and c:income(1)==startingIncome,
   'New purchase reserves funds without early income: '..kind)
  local pickupTime=100+Rules.ContestWindow+.01
  c:advance(pickupTime)
  check(c.players[1].carry==uid and c.items[uid].state=='PurchaseCarry','New item enters purchase carry: '..kind)
  check(c:finish(1,true,pickupTime+1),'New item delivers: '..kind)
  check(c.items[uid].owner==1 and c.items[uid].state=='Stored'
   and c.players[1].held==0 and c.players[1].cash==10000000-catalogItem.price
   and c:income(1)==startingIncome+catalogItem.income,'New delivery commits once with correct income: '..kind)
  check(not c:finish(1,true,pickupTime+1),'New item rejects duplicate delivery: '..kind)
  check(c:beginSteal(2,uid,110),'New item can be stolen after storage: '..kind)
  check(c:income(1)==startingIncome and not c:power(2,111,'tag'),'New theft pauses income and carrier powers: '..kind)
  check(c:finish(2,false,112),'New theft can recover: '..kind)
  check(c.items[uid].owner==1 and c:income(1)==startingIncome+catalogItem.income,
   'Interrupted theft restores original owner and income: '..kind)
  check(c:beginSteal(2,uid,113) and c:finish(2,true,114),'New item theft transfers on delivery: '..kind)
  check(c.items[uid].owner==2 and c.players[2].capacity==8,'New collectible preserves eight-slot base limit: '..kind)
  local retry=c:setOffer('refund-'..kind,kind,120,42)
  local cash=c.players[1].cash
  check(c:purchaseAttempt(1,retry.id,retry.token,120),'New item second purchase reserves: '..kind)
  c:advance(120+Rules.ContestWindow+.01)
  check(c:finish(1,false,123),'New item interrupted carry refunds: '..kind)
  check(c.players[1].cash==cash and c.players[1].held==0
   and c.items[retry.uid].state=='Conveyor' and retry.x==42,'New refund restores funds and original belt position: '..kind)
 end
 return string.format('%d checks; all 46 models supported, original 42 stats preserved, new-item delivery/refund/theft passed; Pokemon %.3f%% -> %.3f%% (sample %.3f%%)',
  checks,oldPokemon*100,newPokemon*100,seenPokemon/samples*100)
end
