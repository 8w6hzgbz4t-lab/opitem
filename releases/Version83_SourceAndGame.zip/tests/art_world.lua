local Mock=dofile("tools/roblox_mock.lua")
local WorldArt=Mock.loadModule("roblox/art/WorldArt.lua")
local parent=Instance.new("Model");parent.Name="DetailedWorldPreview"
local root=Instance.new("Part");root.Name="PreviewRoot";root.Transparency=1;root.Anchored=true
root.CanCollide=false;root.CanTouch=false;root.CanQuery=false;root.Parent=parent;parent.PrimaryPart=root
local aesthetics=Instance.new("Folder");aesthetics.Name="Aesthetics";aesthetics.Parent=parent
local world={folder=parent,bases={}}
for i=1,8 do
 local x=-84+((i-1)%4)*56;local z=i<=4 and -57 or 57
 world.bases[i]={cf=CFrame.new(x,0,z)*CFrame.Angles(0,z<0 and math.pi or 0,0)}
end
local phase=Instance.new("Folder");phase.Name="PhaseDecor";phase.Parent=parent
for _,name in ipairs({"MidnightLotus","LotusScenicPedestal","LotusGem","RiftArchiveCard","DisposalFacade","DisposalRoof","PowerShop"}) do
 local p=Instance.new("Part");p.Name=name;p.Parent=phase;p.Anchored=true
end
WorldArt.pillars(aesthetics);WorldArt.monument(aesthetics);WorldArt.tower(aesthetics)
WorldArt.stoneHead(aesthetics);WorldArt.roofs(aesthetics,world.bases);WorldArt.skyFlowers(aesthetics)
WorldArt.buildBackground(world);WorldArt.addDecorations(world)
assert(phase:FindFirstChild("DisposalFacade") and phase:FindFirstChild("DisposalRoof") and phase:FindFirstChild("PowerShop"),"Gameplay scenery removed")
assert(not phase:FindFirstChild("MidnightLotus") and not phase:FindFirstChild("RiftArchiveCard"),"Old art not replaced")
local roofs=aesthetics:FindFirstChild("VaultRoofs")
assert(#roofs:GetChildren()==8,"Missing base roofs")
for i,roof in ipairs(roofs:GetChildren()) do
 assert(roof.Name=="BaseRoof"..i and roof:GetAttribute("BaseCF"),"Roof camera contract broken")
 local solid=roof:FindFirstChild("SolidFittedRoof")
 assert(solid and solid.CanCollide and solid.CanQuery,"Roof not solid")
 local localPosition=world.bases[i].cf:PointToObjectSpace(solid.CFrame.Position)
 assert(math.abs(localPosition.Y-solid.Size.Y/2-17.5)<1e-6,"Roof clearance changed")
 assert(solid.Size.X>=48 and solid.Size.Z>=48,"Roof does not cover base")
end
local background=parent:FindFirstChild("BackgroundArt")
local portal=background:FindFirstChild("OrnateRiftFrame")
for _,p in ipairs(portal:GetDescendants()) do if p:IsA("BasePart") then assert(not p.CanCollide and not p.CanQuery,"Portal blocks item path") end end
local dome=background:FindFirstChild("VioletDomainDome")
assert(dome and #dome:GetChildren()>300,"Dome missing")
local mirror=background:FindFirstChild("MirrorForceReflectionPlanet")
assert(mirror and mirror:GetAttribute("FlatBackdrop"),"Mirror Force-inspired planet missing")
assert(not background:FindFirstChild("DistantPlanet"),"Old planet was not replaced")
assert(mirror:FindFirstChild("ReflectionBurstCore") and mirror:FindFirstChild("FloatingMirrorShard_0_A"),"Reflection artwork incomplete")
local landmarks=parent:FindFirstChild("DetailedLandmarks")
local track=landmarks:FindFirstChild("FiveDsDuelCircuit")
assert(track and track:GetAttribute("ConveyorGeometryUnchanged"),"Circuit missing or conveyor contract changed")
local road=track:FindFirstChild("PortalRoadDeck")
assert(road and road.Size.X==302 and road.Size.Z==12 and road.CFrame.Position.Y+road.Size.Y/2<.6,"Portal road obstructs belt")
assert(track:FindFirstChild("CircuitAsphalt_1") and track:FindFirstChild("CircuitAsphalt_36"),"Racetrack loop incomplete")
for _,p in ipairs(track:GetChildren()) do
 if p:IsA("BasePart") and p.Name:match("^CircuitAsphalt_") then
  assert(p.CFrame.Position.Y>=32,"Outer circuit is hidden behind the perimeter wall")
 end
end
local spur=track:FindFirstChild("PortalClimbingSpur")
assert(spur and spur.CFrame.Position.X>125 and spur.CFrame.Position.Y>10,"Raised track has no portal spur")
assert(track:FindFirstChild("SpurEnergyStrip_1") and track:FindFirstChild("CircuitSupportBeacon_1"),"Raised circuit lighting missing")
for _,name in ipairs({"CrimsonDragonMonument","ShenronDragonMonument","FiveDsDuelCircuit"}) do
 local model=landmarks:FindFirstChild(name)
 assert(model and model:GetAttribute("DecorativeOnly"),"Requested decoration missing: "..name)
 for _,p in ipairs(model:GetDescendants()) do
  if p:IsA("BasePart") then
   assert(not p.CanCollide and not p.CanTouch and not p.CanQuery,"Scenery interferes with gameplay: "..p.Name)
   if name~="FiveDsDuelCircuit" and p.Name~="Root" then
    assert(p.CFrame.Position.Y>30,"Dragon is hidden below the walls")
   end
  end
 end
end
assert(#track:GetChildren()<=300,"Track part budget exceeded")
assert(landmarks:FindFirstChild("CrimsonDragonMonument"):FindFirstChild("ScarletWingMembrane_-1_1_A"),"Crimson wings missing")
assert(landmarks:FindFirstChild("ShenronDragonMonument"):FindFirstChild("WhiskerOuter_1"),"Shenron facial details missing")
local count=0
for _,p in ipairs(parent:GetDescendants()) do
 if p:IsA("BasePart") then count=count+1;assert(p.Anchored,"Unanchored scenery") end
end
parent:SetAttribute("PartCount",count)
local recorded=Mock.record(parent)
local f=assert(io.open("/tmp/opitem-world-art.json","w"));f:write(Mock.json(recorded));f:close()
print("PASS: fitted solid roofs, camera metadata, nonblocking portal/5D's circuit, detailed dragons above walls, Mirror Force planet, dome, and preserved disposal/shop")
print("Recorded "..count.." scenery parts to /tmp/opitem-world-art.json")
