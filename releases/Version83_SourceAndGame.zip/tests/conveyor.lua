local Core=dofile('roblox/OPItemV2/Core.lua')
local Catalog=dofile('roblox/OPItemV2/Catalog.lua')
local Config=dofile('roblox/OPItemV2/Config.lua')
local Conveyor=dofile('roblox/OPItemV2/Conveyor.lua')
local checks=0
local function check(ok,msg) assert(ok,msg); checks=checks+1 end
-- Every shipped source must parse, including scripts requiring Roblox at runtime.
for _,name in ipairs({'Catalog','Config','Core','ModelFactory','World','Server','Client','Conveyor'}) do
 check(loadfile('roblox/OPItemV2/'..name..'.lua')~=nil,name..' syntax')
end
local core=Core.new(Catalog,Config)
core:addPlayer(1,0); core:addPlayer(2,0)
core.players[1].cash=10000000; core.players[2].cash=10000000
local spawns,removals=0,0
local belt=Conveyor.new(3,28.875,12,function(id,now,kind)
 spawns=spawns+1; core:setOffer(id,kind or 'item01')
end,function(id) removals=removals+1; core.offers[id]=nil end)
belt:step(0); check(spawns==1,'immediate portal spawn')
belt:step(2.99); check(spawns==1,'spacing interval')
belt:step(3); check(spawns==2,'three second spawn')
local token=core.offers[1].token
check(core:buy(1,1,token),'first purchase')
check(not core:buy(2,1,token),'second player cannot duplicate purchase')
check(belt:remove(1),'remove purchased model')
check(not belt:remove(1),'idempotent cleanup')
local stale=core.offers[2].token
check(not core:buy(2,2,'forged'),'forged token rejected')
check(not belt:isActive(2,31.875),'deadline rejects before cleanup')
belt:step(32); check(core.offers[2]==nil,'expired offer removed from economy')
check(not core:buy(2,2,stale),'expired purchase rejected')
local before=spawns; belt:step(100); check(spawns==before+1,'lag creates no burst')
for i=1,10000 do belt:step(100+i*.1); check(belt.count<=10,'bounded active offers') end
-- Hard capacity, including incoming stolen items.
for i=1,5 do check(core:grant(1,'item01')~=nil,'fill seven slots') end
check(core.players[1].capacity==8,'fixed capacity')
local victim=core.players[2].slots[1]
check(core:beginSteal(1,victim,1000),'reserve eighth slot for stolen item')
core:setOffer(20000,'item01')
check(not core:buy(1,20000,core.offers[20000].token),'cannot buy while carrying')
check(core:grant(1,'item01')==nil,'reserved slot blocks ninth item')
check(core:finish(1,true),'complete theft')
check(#core:snapshot(1,1000).inventory==8,'eight owned items after delivery')
local cash=core.players[1].cash
check(not core:upgrade(1),'no expansion beyond eight')
check(core.players[1].cash==cash and core.players[1].capacity==8,'no charge for disabled expansion')
check(not core:buy(1,20000,core.offers[20000].token),'full vault blocks purchase')
check(core.players[1].cash==cash,'full purchase costs nothing')
local oldbank=core.players[1].bank; core:tick(2)
check(core.players[1].bank-oldbank==core:income(1)*2,'passive income preserved')
-- Actual catalog roll uses only existing entries and tier weights.
local rng={NextNumber=function() return 0 end,NextInteger=function(_,a,b) return a end}
check(Catalog.ById[Catalog.roll(rng)].tier==1,'common boundary')
rng.NextNumber=function() return .999999 end
check(Catalog.ById[Catalog.roll(rng)].tier==7,'rarest boundary')
print('PASS: '..checks..' assertions (syntax, lifecycle, purchases, capacity, income, catalog)')
